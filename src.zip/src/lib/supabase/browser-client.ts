import { createBrowserClient } from '@supabase/auth-helpers-nextjs';

export const createSupabaseBrowserClient = () => {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
};

// Singleton instance for client-side usage
let client: ReturnType<typeof createSupabaseBrowserClient> | undefined;

export const getSupabaseBrowserClient = () => {
  if (!client) {
    client = createSupabaseBrowserClient();
  }
  return client;
};
