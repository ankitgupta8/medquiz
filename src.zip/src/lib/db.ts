import { config } from 'dotenv';
import { resolve } from 'path';

// Force load .env file with override to beat system env vars
const envResult = config({ path: resolve(process.cwd(), '.env'), override: true });

if (envResult.error) {
  console.error('[DB] Failed to load .env:', envResult.error.message);
} else {
  console.log('[DB] Loaded .env - DATABASE_URL:', process.env.DATABASE_URL?.substring(0, 40) + '...');
}

import { PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as { prisma: PrismaClient | undefined };

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['error', 'warn'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db;
